# Reuse and redistribution terms

The release package may be copied and analysed under the repository licence.
Keep the release edition, input commit, source attribution and stated limits
with any reuse. Do not represent the package as a payment, investment or causal
effect dataset.

This archive contains no raw source documents. Individual sources remain subject
to their own terms; their URLs, hashes and locators are supplied for attribution
and verification. No permission to redistribute source PDFs, websites or other
upstream material is granted by this package.
