# JETP public release dictionary

This package is a frozen descriptive release of four Just Energy Transition
Partnership portfolios: South Africa (ZAF), Indonesia (IDN), Viet Nam (VNM)
and Senegal (SEN). It preserves source-specific observations and gaps.

## Identifiers and hierarchy

`project_id` identifies a canonical registry record. A programme, a component
and a financing tranche are different records or observations. They must not be
added as independent projects or financing totals. Viet Nam's unpublished
portfolio identities are count slots, not invented project IDs.

## Dates and stages

`event_date` is distinct from a source publication date, retrieval date and this
release cutoff. A register or report date is not silently treated as a signature
or payment date. Financial stages (need, announced, memorandum, approved,
signed and disbursed) are observations, not additive flows. Implementation
states are a separate evidence layer.

## Totals and currencies

Country headlines reproduce the named national source and retain its currency,
stage, scope and date. They are **not additive** across countries or project
events, and they do not establish a common disbursement total. Every visible
headline links to a source record through `site/data/provenance.json`. Missing
payments remain unavailable rather than zero. Strict JETP attribution and the
extended IPG-energy perimeter remain separate.

## Coverage

The country downloads list named records, source links and the review state at
the stated cutoff. A missing direct source, blocked retrieval, count slot or
unresolved relationship is a recorded gap, not evidence of absence or delivery.
